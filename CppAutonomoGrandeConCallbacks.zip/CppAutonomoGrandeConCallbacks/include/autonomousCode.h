#include "vex.h"
#include <vector>
#include <functional>

#pragma once // Para evitar errores de definición múltiple

using namespace vex;

// Librerías propias
#include "configuration.h"
#include "funciones_posicionales.h"

/* int main() {
    driveForDistance(24, 50, 5000, Callbacks(), {});
} */